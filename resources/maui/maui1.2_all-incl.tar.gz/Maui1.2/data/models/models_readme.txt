Several models were pre-computed using my data
and are now available here:
theses80 - using 80 masters and phd theses from university of waikato and library of congress subject headings as a vocabulary
nlm500 - using 500 medical articles and medical subject headings as a vocabulary
fao30 - using 30 agricultural documents and agrovoc terms as a vocabulary
cern290 - using physics documents and high energy physics thesaurus as a vocabulary
