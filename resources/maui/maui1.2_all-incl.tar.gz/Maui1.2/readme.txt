Maui is multi-purpose automatic indexing tool.
You can read more about it on:
http://maui-indexer.googlecode.com/
and in the blog
http://maui-indexer.blogspot.com/

For a quick start, import Maui into Eclipse,
add all jars in the lib folder as Rereferenced libraries,
then run MauiWrapper -Xmx512m data/term_assignment/test/w7539e.txt
You should see the following output:
Keyword: Forestry
Keyword: Afforestation
Keyword: Disasters
Keyword: Desertification
Keyword: Taiwan
Keyword: China
Keyword: Degradation
Keyword: Climate
Keyword: Soil
Keyword: Deserts
Keyword: Sand


